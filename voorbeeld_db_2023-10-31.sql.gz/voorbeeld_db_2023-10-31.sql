# ************************************************************
# Sequel Ace SQL dump
# Version 20051
#
# https://sequel-ace.com/
# https://github.com/Sequel-Ace/Sequel-Ace
#
# Host: 127.0.0.1 (MySQL 11.1.2-MariaDB-1:11.1.2+maria~ubu2204)
# Database: voorbeeld_db
# Generation Time: 2023-10-31 08:14:10 +0000
# ************************************************************


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
SET NAMES utf8mb4;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE='NO_AUTO_VALUE_ON_ZERO', SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


# Dump of table cake
# ------------------------------------------------------------

DROP TABLE IF EXISTS `cake`;

CREATE TABLE `cake` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(250) DEFAULT NULL,
  `disc` varchar(250) DEFAULT NULL,
  `img` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

LOCK TABLES `cake` WRITE;
/*!40000 ALTER TABLE `cake` DISABLE KEYS */;

INSERT INTO `cake` (`id`, `title`, `disc`, `img`)
VALUES
	(1,'medovik','Medovik (Russian: медови́к (medovik), from мёд/мед — \"honey\") is a layer cake popular in countries of the former Soviet Union.','./img/medovik.jpg'),
	(2,'tiramisu','Tiramisu appears to have been invented in the 1960s, but where and when exactly is unclear.','./img/tiramisu.jpg'),
	(3,'choco cake','Chocolate cake is made with chocolate. It can also include other ingredients.[1] These include fudge, vanilla creme, and other sweeteners.','./img/choco.jpg'),
	(4,'choco','Chocolate cake is made with chocolate. It can also include other ingredients.[1] These include fudge, vanilla creme, and other sweeteners.','./img/choco.jpg');

/*!40000 ALTER TABLE `cake` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table mainPage
# ------------------------------------------------------------

DROP TABLE IF EXISTS `mainPage`;

CREATE TABLE `mainPage` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(250) DEFAULT NULL,
  `img` varchar(250) DEFAULT NULL,
  `url` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

LOCK TABLES `mainPage` WRITE;
/*!40000 ALTER TABLE `mainPage` DISABLE KEYS */;

INSERT INTO `mainPage` (`id`, `title`, `img`, `url`)
VALUES
	(1,'chocolade cake','../img/choco.jpg','http://localhost:8080/cake1'),
	(3,'tiramisu','../img/tiramisu.jpg','http://localhost:8080/cake2'),
	(4,'Medovik','../img/medovik.jpg','http://localhost:8080/cake3');

/*!40000 ALTER TABLE `mainPage` ENABLE KEYS */;
UNLOCK TABLES;



/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
